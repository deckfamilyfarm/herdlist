import { ImportWizard } from '../ImportWizard';

export default function ImportWizardExample() {
  return (
    <div className="p-6 max-w-2xl">
      <ImportWizard />
    </div>
  );
}
