import { ReportFilters } from '../ReportFilters';

export default function ReportFiltersExample() {
  return (
    <div className="p-6 max-w-3xl">
      <ReportFilters />
    </div>
  );
}
