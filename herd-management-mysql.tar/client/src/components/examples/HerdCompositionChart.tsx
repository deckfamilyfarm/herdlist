import { HerdCompositionChart } from '../HerdCompositionChart';

export default function HerdCompositionChartExample() {
  return (
    <div className="p-6">
      <HerdCompositionChart />
    </div>
  );
}
